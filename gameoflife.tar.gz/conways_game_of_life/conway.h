
//game structures
void r_pentominio();
void diehard();
void acorn();

//mechanics
void visualize();
int * nextframe();
int * createEnvironment();
