
//structures
void r_pentominio();
void diehard();
void acorn();
void beacon();
void glider();

//mechanics
void visualize();
void nextframe();
